# Andreas Hadjipanayiotou — Android App

Έτοιμο Android project για GitHub / GitHub Actions, σχεδιασμένο για viewport περίπου **430 × 932 dp** και με αισθητική βασισμένη στο mockup που δόθηκε.

## Περιλαμβάνει
- Αρχική οθόνη με hero εικόνα, όνομα και signature.
- Κεντρικά tabs: **Demos / Στίχοι / Κυκλοφορίες / Βιογραφικό**.
- Κουμπί **Διαχείριση** επάνω δεξιά.
- Τοπικό admin panel με PIN.
- Προσθήκη **MP3 απευθείας από το κινητό** μέσω Android file picker.
- Τα MP3 αντιγράφονται στον ιδιωτικό χώρο της εφαρμογής, ώστε να παραμένουν διαθέσιμα μετά το κλείσιμο.
- Προσθήκη / διαγραφή demos.
- Προσθήκη / διαγραφή στίχων.
- Προσθήκη / διαγραφή κυκλοφοριών.
- Επεξεργασία βιογραφικού.
- Βασικός ενσωματωμένος audio player με play/pause και seek.
- Όλα τα δεδομένα αποθηκεύονται τοπικά στη συσκευή.

## Admin PIN
Προεπιλογή: `1234`

> Σημείωση: Το συγκεκριμένο project είναι **local-first**. Ό,τι προσθέτεις από το admin αποθηκεύεται στη συγκεκριμένη συσκευή. Δεν υπάρχει ακόμη online database/cloud συγχρονισμός.

## Build από GitHub
Το workflow βρίσκεται εδώ:

`.github/workflows/build-apk.yml`

Με κάθε push στο `main` ή χειροκίνητα από **Actions → Build Android APK**, το GitHub Actions δημιουργεί APK artifact.

## Package
`com.andreashadjipanayiotou.app`

## Επόμενο βήμα για Play Store
Για Google Play χρειάζεται production signing key και AAB. Το project είναι δομημένο ώστε να προστεθεί signing configuration αργότερα.
